## Changelog

### [v1.1.0] - 2024-04-16

#### Added

- Added new option `Copy value` on json elements option list.
- Can now customize values color and `Copy value` indent size for array and object.

### [v1.0.3] - 2024-04-13

#### Changed

- `Copy path` now copies the index path to clipboard right away.

### [v1.0.2] - 2024-04-13

#### Changed

- Fixed cannot parse some json source.

### [v1.0.1] - 2024-03-28

#### Changed

- Optimized visualizer
- Visualizer is now responsive to acode theme.
